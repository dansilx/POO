﻿using AlunoConstrutor;

Aluno aluno1 = new Aluno();
aluno1.Nome = "Lucas Tozzi";
aluno1.Prova1 = 8;
aluno1.Prova2 = 10;
aluno1.MostrarAtributos();

Aluno aluno2 = new Aluno();
aluno2.Nome = "Lara Baptista";
aluno2.Prova1 = 9;
aluno2.Prova2 = 7;
aluno2.MostrarAtributos();

Aluno aluno3 = new Aluno();
aluno3.Nome = "Igor Cremonezi";
aluno3.Prova1 = 7;
aluno3.Prova2 = 8;
aluno3.MostrarAtributos();

Aluno aluno4 = new Aluno();
aluno4.Nome = "Kelly Nunes";
aluno4.Prova1 = 8;
aluno4.Prova2 = 8;
aluno4.MostrarAtributos();