﻿using HerancaFuncionario;

Funcionario f = new Funcionario(1, "Davi", 1500);
f.Mostrar();

Horista h = new Horista(2, "João", 1600, 80);
h.Mostrar();

Mensalista m = new Mensalista(3, "Ricardo", 1700, 350);
m.Mostrar();
